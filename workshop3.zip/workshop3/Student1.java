package workshop3;

import java.io.FileWriter;
import java.io.IOException;

public class Student1 {

    private int id;
    private String name;
    private int age;
    private char grade;

    public Student1(int id, String name, int age, char grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public char getGrade() {
        return grade;
    }

    public static void saveToCSV(Student1[] students, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
          
            writer.write("ID,Name,Age,Grade\n");

            for (Student1 student : students) {
                writer.write(student.getId() + "," + student.getName() + "," + student.getAge() + "," + student.getGrade() + "\n");
            }

            System.out.println("Data successfully written to " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
  
        Student1[] students = {
            new Student1(1, "Ram", 30, 'A'),
            new Student1(2, "Hari", 12, 'B'),
            new Student1(3, "Shiv", 29, 'C')
        };

        saveToCSV(students, "students.csv");
    }
}

