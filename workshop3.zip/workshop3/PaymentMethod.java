package workshop3;

interface PaymentMethod {
	public void processPayment(double amount);
	
}
class Esewa implements PaymentMethod{
	@Override
	public void processPayment(double amount) {
		System.out.println("Processing payemnt of rs."+amount + "through esewa");
	}
}
class Khalti implements PaymentMethod{
	@Override
	public void processPayment(double amount) {
		System.out.println("Processing payemnt of rs."+amount + "through khalti");
	}
}
class Interface{
	public static void main(String[] args) {
		
		PaymentMethod esewa= new Esewa();
		esewa.processPayment(2000);
		
		PaymentMethod khalti = new Khalti();
		khalti.processPayment(2000);
		
		
	}
}
