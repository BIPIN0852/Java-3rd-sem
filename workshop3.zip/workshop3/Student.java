package workshop3;

public class Student {
	private int id;
	private int age;
	private  String name;
	private int grade;
	
	public Student(int id,int age,String name,int grade) {
		this.id=id;
		this.age=age;
		this.name=name;
		this.grade=grade;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		if (age>0) {
			this.age = age;
	}	else { 
		System.out.println("Invalid age.Age must be positive.");
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		if (grade>='A'&& grade <='F') {
			this.grade = grade;
	}else {
		System.out.println("Invalid grade.Grade must be between A and F");
		}
	}
		public static void main(String[] args) {
			Student student = new Student(13,10,"Bipin",'A');
			
			System.out.println("ID: "+student.getId());
			System.out.println("Age: "+student.getAge());
			System.out.println("Name: "+student.getName());
			System.out.println("Grade: "+student.getGrade());
			
			student.setName("Santosh");
			student.setAge(22);
			student.setGrade('B');
			
			System.out.println("Updated Name: "+student.getName());
			System.out.println("Updated Age: "+student.getAge());
			System.out.println("Updated Grade: "+student.getGrade());			
		}
	}
	