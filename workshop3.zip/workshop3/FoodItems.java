package workshop3;
import java .io.*;
import java.util.*;

public class FoodItems {
	public static void main(String[] args) {
		try(Scanner scanner = new Scanner(System.in);
				FileWriter writer= new FileWriter("food.txt",true)){
			System.out.println("Enter food name (type 'exit' to stop):");
			while(true) {
				String food= scanner.nextLine();
				if(food.equalsIgnoreCase("exit")) {
					break;
					
				}
				writer.write(food + "\n");
			}
			System.out.println("Food names save to food.txt");
		}catch(IOException e) {
			System.out.println("An error occured: "+e.getMessage());
		}
	}

}
