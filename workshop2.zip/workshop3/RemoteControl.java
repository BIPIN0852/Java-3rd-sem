package workshop3;

interface RemoteControl {
	
	public void PowerOn();
	public void PowerOff();
}

class TV implements RemoteControl{
	@Override
	public void PowerOn() {
		System.out.println("TV is on.");
		
	}
	@Override
	public void PowerOff() {
		System.out.println("Tv is off.");
	}
	
}
class AC implements RemoteControl{
	@Override
	public void PowerOn(){
		System.out.println("Ac is on.");
		
	}
	@Override
	public void PowerOff() {
		System.out.println("Ac is Off");
	}
	
}
class InterfaceRemote{
	public static void main(String[] args) {
		
		RemoteControl tv= new TV();
		tv.PowerOn();
		tv.PowerOff();
		
		RemoteControl ac= new AC();
		ac.PowerOn();
		ac.PowerOff();

	}

}
