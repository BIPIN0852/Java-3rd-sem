package workshop3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Student2 {

    private int id;
    private String name;
    private int age;
    private char grade;


    public Student2(int id, String name, int age, char grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public char getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Grade: " + grade;
    }

    public static List<Student2> readFromCSV(String filename) {
        List<Student2> students = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line = reader.readLine(); 
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();
                int age = Integer.parseInt(parts[2].trim());
                char grade = parts[3].trim().charAt(0);
                students.add(new Student2(id, name, age, grade));
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        return students;
    }

    public static void main(String[] args) {
    
        List<Student2> students = readFromCSV("students.csv");

        students.sort(Comparator.comparing(Student2::getGrade));

        System.out.println("List of students sorted by grade:");
        for (Student2 student : students) {
            System.out.println(student);
        }
    }
}