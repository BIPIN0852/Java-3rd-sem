package workshop3;

public abstract class Vehicle {
    public abstract void startEngine();

    public abstract void stopEngine();

    public static class Car extends Vehicle {
        @Override
        public void startEngine() {
            System.out.println("Car engine starting..");
        }

        @Override
        public void stopEngine() {
            System.out.println("Car is stopping..");
        }
    }

    public static class Motorcycle extends Vehicle {
        @Override
        public void startEngine() {
            System.out.println("Motorcycle engine is starting..");
        }

        @Override
        public void stopEngine() {
            System.out.println("Motorcycle engine is stopped..");
        }
    }

    public static class Main {
        public static void main(String[] args) {
            Vehicle car = new Car();
            car.startEngine();
            car.stopEngine();

            Vehicle motorcycle = new Motorcycle();
            motorcycle.startEngine();
            motorcycle.stopEngine();
        }
    }
}
