package workshop3;

public abstract class GameCharacter {
	public abstract void attack();
	public abstract void defend();

}
 class Warrior extends GameCharacter{
	@Override
	public void attack() {
		System.out.println("Warrior attacks..");
		
	}
	@Override
	public void defend() {
		System.out.println("Warrior defends..");
	}
	
}
 class Archer extends GameCharacter{
	 @Override
	 public void attack() {
		 System.out.println("Archer attacks..");
	 }
	 @Override
	 public void defend() {
		 System.out.println("Archer defends..");
	 }
 }
  class Main {
	 public static void main(String[] args) {
		 GameCharacter warrior= new Warrior();
		 warrior.attack();
		 warrior.defend();
		 
		 GameCharacter archer= new Archer();
			 archer.attack();
			 archer.defend();
		
	}
	 
 }