package workshop2;

class Annimal {
 String name;

 public Annimal(String name) {
     this.name = name;
     System.out.println("Animal constructor called.");
 }

 public void displayInfo() {
     System.out.println("Animal Name: " + name);
 }
}


class Doggg extends Annimal {
 String breed;

 public Doggg(String name, String breed) {
     super(name);
     this.breed = breed;
     System.out.println("Dog constructor called.");
 }

 @Override
 public void displayInfo() {
     super.displayInfo(); 
     System.out.println("Breed: " + breed);
 }
}

class Animal1 {
 public static void main(String[] args) {
     Doggg dog = new Doggg("Saggy", "Votey");

     dog.displayInfo();
 }
}
