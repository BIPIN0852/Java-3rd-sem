package workshop2;

class Shape {

 public double getPerimeter() {
     System.out.println("Perimeter calculation is not defined for Shape.");
     return 0;
 }

 public double getArea() {
     System.out.println("Area calculation is not defined for Shape.");
     return 0;
 }
}


class Circle extends Shape {
 double radius;


 public Circle(double radius) {
     this.radius = radius;
 }

 @Override
 public double getPerimeter() {
     return 2 * Math.PI * radius; 
 }

 @Override
 public double getArea() {
     return Math.PI * radius * radius; 
 }
}

 class Shape1 {
 public static void main(String[] args) {
     
     Circle circle = new Circle(5.0);

     System.out.println("Circle Perimeter: " + circle.getPerimeter());
     System.out.println("Circle Area: " + circle.getArea());
 }
}
