package workshop2;

public class Calculator {
	
	public int add(int a,int b) {
		return a+b;
	}
	

	public int add(int a, int b, int c) {
		return a+b+c;
	}
	
	public double add(double a,double b) {
		return a+b;
	}
	
	public double add(double a,double b,double c) {
		return a+b+c;
	}
	
	
	public static void main(String[] args) {
		Calculator calc= new Calculator();
		int intResult1= calc.add(4, 5);
		System.out.println("the sum of two(4 and 5) is: "+intResult1);
		
		int intResult2=calc.add(3, 5, 6);
		System.out.println("the sum of three(3,5,6) is: "+intResult2);
		
		double doubleResult1=calc.add(2.4, 3.6);
		System.out.println("the sum pf two double (2.4 and 3.6)  is: "+doubleResult1);
		
		double doubleResult2=calc.add(4.5, 5.5,5.0);
		System.out.println("The sum of three(4.5,5.5,5.0 is: "+doubleResult2);
		
		
	}
}
