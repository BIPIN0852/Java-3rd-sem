package workshop2;

class Parent {
 private String privateVariable = "Private Variable"; 
 protected String protectedVariable = "Protected Variable"; 
 public String publicVariable = "Public Variable"; 

 public String getPrivateVariable() {
     return privateVariable;
 }
}

class Child extends Parent {

 public void displayVariables() {
   
     System.out.println("Accessing Protected Variable: " + protectedVariable); 
     System.out.println("Accessing Public Variable: " + publicVariable);

     System.out.println("Accessing Private Variable through method: " + getPrivateVariable());
 }
}

public class Person2 {
 public static void main(String[] args) {
     
     Child child = new Child();

     child.displayVariables();
 }
}

