package workshop2;

final class FinalClass {

 public void displayMessage() {
     System.out.println("This is a final class.");
 }
}

//class ExtendedClass extends FinalClass {
//}

class ParentClass {
 
 public final void finalMethod() {
     System.out.println("This is a final method.");
 }

 public void regularMethod() {
     System.out.println("This is a regular method in the parent class.");
 }
}


class SubClass extends ParentClass {

 // @Override
 // public void finalMethod() {
 //     System.out.println("Trying to override the final method.");
 // }

 @Override
 public void regularMethod() {
     System.out.println("This is the overridden regular method in the subclass.");
 }
}

class Final2 {
 public static void main(String[] args) {

     FinalClass finalClass = new FinalClass();
     finalClass.displayMessage();

     SubClass subClass = new SubClass();
     subClass.finalMethod(); 
     subClass.regularMethod(); 
 }
}

	

