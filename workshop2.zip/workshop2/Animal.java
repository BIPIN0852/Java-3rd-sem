package workshop2;

class Animal {
 String name;
 int age;

 // Constructor for Animal
 public Animal(String name, int age) {
     this.name = name;
     this.age = age;
 }

 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}

class Dog extends Animal {
 String breed;

 // Constructor for Dog
 public Dog(String name, int age, String breed) {
     
     super(name, age);
     this.breed = breed;
 }

 @Override
 public void displayInfo() {
     super.displayInfo(); 
     System.out.println("Breed: " + breed);
 }
}

 class Main{
 public static void main(String[] args) {

     Dog dog = new Dog("Saggy", 7, "Votey");

     dog.displayInfo();
 }
}
