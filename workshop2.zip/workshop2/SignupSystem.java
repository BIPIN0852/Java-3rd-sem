package workshop2;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

class SignupSystem {

    static class User {
        String fullName;
        String mobileNumber;
        String password;
        String dob;

        User(String fullName, String mobileNumber, String password, String dob) {
            this.fullName = fullName;
            this.mobileNumber = mobileNumber;
            this.password = password;
            this.dob = dob;
        }
    }

    private static ArrayList<User> users = new ArrayList<>();

    public static boolean isValidFullName(String fullName) {
        return fullName.length() > 4;
    }

    public static boolean isValidMobileNumber(String mobileNumber) {
        return mobileNumber.matches("0\\d{9}");
    }

    public static boolean isValidPassword(String password) {
        return password.matches("[A-Z].*[@&].*\\d$");
    }

    public static boolean isValidDOB(String dob) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate dateOfBirth = LocalDate.parse(dob, formatter);
            LocalDate today = LocalDate.now();
            long age = ChronoUnit.YEARS.between(dateOfBirth, today);
            return age >= 21;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Please enter 1 for Sign up.");
            System.out.println("Please enter 2 for Quit.");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 2) {
                System.out.println("Application Quit. Goodbye!");
                running = false;
            } else if (choice == 1) {
                while (true) {
                    System.out.print("Please enter your full name: ");
                    String fullName = scanner.nextLine();
                    if (!isValidFullName(fullName)) {
                        System.out.println("Full name must be longer than 4 characters.");
                        continue;
                    }

                    System.out.print("Please enter your mobile number (username): ");
                    String mobileNumber = scanner.nextLine();
                    if (!isValidMobileNumber(mobileNumber)) {
                        System.out.println("Mobile number must have 10 digits and start with 0.");
                        continue;
                    }

                    System.out.print("Please enter your password: ");
                    String password = scanner.nextLine();
                    if (!isValidPassword(password)) {
                        System.out.println("Password must start with a capital letter, include @ or &, and end with a number.");
                        continue;
                    }

                    System.out.print("Please confirm your password: ");
                    String confirmPassword = scanner.nextLine();
                    if (!password.equals(confirmPassword)) {
                        System.out.println("Passwords do not match.");
                        continue;
                    }

                    System.out.print("Please enter your Date of Birth (DD/MM/YYYY): ");
                    String dob = scanner.nextLine();
                    if (!isValidDOB(dob)) {
                        System.out.println("Invalid Date of Birth or you must be at least 21 years old.");
                        continue;
                    }

                    users.add(new User(fullName, mobileNumber, password, dob));
                    System.out.println("You have successfully signed up.");
                    break;
                }
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
