package workshop1;
import java.util.*;

public class Qsn11 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the distance in miles: ");
		 double m = sc.nextDouble();
		  double km = m*1.6;
		   System.out.println("the distance in kilometer is: " +km);

	}
}
