package workshop1;

	class jack {
	    jack(){
	        System.out.println("Jack");
	        System.out.println("Pokhara");
	    }
	}
	class rocky {
	    rocky(){
	        System.out.println("Rocky");
	        System.out.println("Ktm");
	    }
	}

	public class Qsn15 {

	    public static void main(String[] args) {
	    	jack r = new jack();
	    	rocky s = new rocky() ;
	    }
	}


