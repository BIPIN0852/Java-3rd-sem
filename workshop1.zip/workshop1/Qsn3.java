package workshop1;

public class Qsn3 {

	public static void main(String[] args) {
		int a=23;
        double b =34.5;
        char s='A';
        System.out.println(a +"\n" + b+"\n" + s);

	}

}
