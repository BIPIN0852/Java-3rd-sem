package workshop1;
import java.util.*;

public class Qsn14 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the the dollar: ");
		double d= sc.nextDouble();
		double er=135;	
		double ca=d*er;
		System.out.println("The converted amount is: " +ca);
		
	}

}
