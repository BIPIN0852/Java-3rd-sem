package workshop1;

public class Qsn1 {

	public static void main(String[] args) {
		        String var = "ram";
		        System.out.println("hey there \n i am " + var);
		    }
	}

