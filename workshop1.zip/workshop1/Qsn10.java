package workshop1;
import java.util.*;

public class Qsn10 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		   System.out.println("enter the length: ");
		   double l = sc.nextDouble();

		   System.out.println("enter the width:  ");
		   double b = sc.nextDouble();
		   double p = 2*(l+b);

		   System.out.println("the perimeter of rectangle is: " +p);

	}
}
