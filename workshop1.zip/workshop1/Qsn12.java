package workshop1;
import java.util.*;

public class Qsn12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the radius of circle: ");
		double r= sc.nextDouble();
		double a= 3.14*r*r;
		System.out.println("the area of circle is: " +a);

	}
}
