package workshop1;
import java.util.*;

public class qsn5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		   System.out.println("enter the number :");
		   double a = sc.nextDouble();
		   double sqr = a*a;
		   System.out.println("The square of the number is :" +sqr);

	}

}
