package workshop1;
import java.util.*;

public class qsn6 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		   System.out.println("enter the temperature in celsius: ");
		   double C = sc.nextDouble();
		   double F = (C * 9 / 5) + 32;
		   System.out.println("the temperature in fahrenheit is:"  +F);

	}

}
