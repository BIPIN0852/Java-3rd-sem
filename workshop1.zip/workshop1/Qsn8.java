package workshop1;
import java.util.*;
public class Qsn8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		   System.out.println("enter the principal amount: ");
		   double p = sc.nextDouble();

		   System.out.println("enter the time: ");
		   double t = sc.nextDouble();
		   System.out.println("enter the rate: ");
		   double r = sc.nextDouble();
		   double si = (p*t*r)/100;
		   System.out.println("the simple interst is:" +si);

	}

}
