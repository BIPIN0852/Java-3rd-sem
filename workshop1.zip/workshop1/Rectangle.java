package workshop1;

public class Rectangle {
	private int width;
	private int height;
	
	public Rectangle(int width, int height) {
		this.width=width;
		this.height=height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

   	public void setHeight(int height) {
		this.height = height;
	}
	

	@Override
	public String toString() {
		return "Rectangle[Width="+width+",Height="+height+"]";
	}

	public static void main(String[] args) {
		Rectangle rect=new Rectangle(4,5);
		System.out.println(rect);
		}
}
