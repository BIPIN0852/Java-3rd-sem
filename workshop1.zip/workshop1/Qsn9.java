package workshop1;
import java.util.*;

public class Qsn9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		   System.out.println("enter the first number: ");
		   double a = sc.nextDouble();

		   System.out.println("enter the second number: ");
		   double b = sc.nextDouble();

		   double add = a+b;
		   double sub=a-b;
		   double mul = a*b;
		   double div = a/b;

		   System.out.println(add + "\n" + sub + "\n" + mul + "\n" + div );

	}

}
