package workshop1;

public class qsn2 {
	public static void main(String[] args) {
		int a= 45;
		int b=32;
		int diff,pro;
		diff=a-b;
		System.out.println("the difference is :"+diff);
		pro=a*b;
		System.out.println("the product is :"+pro);
	}
}
