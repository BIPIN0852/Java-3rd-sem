package workshop1;
import java.util.*;

public class Qsn13 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the quantity: ");
		double q= sc.nextDouble();
		System.out.println("Enter the price: ");
		double p= sc.nextDouble();
		
		double t= q*p;
		System.out.println("The total cost is: " +t);
		
	}
}
